<div class="cursor"></div>
<!-- <div class="m"></div> -->

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
<script src="js/vendor/modernizr-3.8.0.min.js"></script>
<script type="text/javascript" src="js/vendor/jquery-1.11.2.min.js"></script>
<script src="js/gsap_scrollmagic.js"></script>
<script src="js/jquery.mCustomScrollbar.js"></script>
<script src="js/parallax.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/kursor"></script> -->
<!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/three.js/84/three.min.js'></script>
<script  src="js/glitch_effect.js"></script> -->
<script src="js/swiper.min.js"></script>
<script src="js/jquery.mousewheel.min.js"></script>

<!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
<!-- <script src="https://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script> -->
<!-- <script src="https://vjs.zencdn.net/7.7.5/video.js"></script> -->
<script src="js/main.js"></script>

<!-- configuration -->
	<input type="hidden" id="environment" value="http://localhost/stc-report/arabic/">

	<script type="text/javascript">
		jQuery('.sm_home').on('click', function(){
			window.location.href = jQuery('#environment').val();
		})
	</script>
<!-- configuration -->