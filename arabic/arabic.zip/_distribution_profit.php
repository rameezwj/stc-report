<!doctype html>
<html class="no-js" lang="">

<?php require_once 'head.php'; ?>

<body class="page_inner">
  <?php
    require_once 'menu_screen.php';
    require_once 'short_menu.php';
    require_once 'vwipes_loader.php';
  ?>

  <div class="page_board outer_wrapper">
    <div class="screentop_para">
      <h1>
        <span class="h1 colr_white bk_purple" style="padding: 5px 15px 5px 150px;">
         أعضاء مجلس الإدارة ولجانه
        </span>
      </h1>
      <h1>
        <span class="h1 colr_purple">
         وتصنيف عضويتهم  
        </span>
      </h1>
    </div>
    
    <div class="cwrapper">
      <div class="img_wrap">
        <div class="left">
           <img src="img/board_boxes.png">
        </div>
        <div class="right">
          <img src="img/board_boxes2.png">
        </div>
      </div>
       <div class="tabular_data">
        <div class="c_row first bk_purple">
          <div>الرئيس</div>
          <div>الرئيس</div>
          <div>الرئيس</div>
          <div>الرئيس</div>
          <div>الرئيس</div>
          <div>الرئيس</div>
          <div>الرئيس</div>
          <div>الرئيس</div>
        </div>
         <div class="c_row bk_purple second">
            <div class="bk_pink"></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </div>
        <div class="tabular_data_inner">
         
          <div class="c_row">
            <div>1</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>
          
          <div class="c_row">
            <div>1</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>2</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>3</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>4</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>
          <div class="c_row">
            <div>5</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>6</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>7</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>8</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>

          <div class="c_row">
            <div>9</div>
            <div>
                          جانه
            صاحب السمو الملكي
            امير/ محمد بن خالد
            العبدالل

            </div>
            <div>
            استاذ/ أحمد بن
            رئيس مجلس •
            </div>
            <div>
            عضو مجلس 
            ادا
            </div>
            <div>
              بائية
              بكالوريوس بحوث
              ماجستير عل
            </div>
            <div>
            ية
            للتقنية
            خبرة في
            </div>
            <div>
            ر
            مستشار
            مستشار
            </div>
            <div>
              حكومي
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="bar-wrap">
        <div class="element_bars_hr" style="width: 30%;top: 0;left: 0;z-index: 1;">
          <div class="rightbar bk_purple" style="width: 50%"></div>
          <div class="leftbar bk_pink" style="width: 50%"></div>
        </div>
        <div class="element_bars_hr" style=" width: 15%;top: 0;right: 20%;z-index: 1;">
          <div class="rightbar bk_purple" style="width: 0%"></div>
          <div class="leftbar bk_pink" style="width: 100%"></div>
        </div>
    </div>
   
  </div>

  <!-- video section | consolidate_financials -->
    <div class="video_wrapper" style="z-index: 99; width: 100%; height: 100vh; position: fixed; top: 0;">
      <video id="category_video" playsinline="" xmuted style="width: 100%; height: 100vh; object-fit: cover; ">
        <source src="video/company_profile.mp4" type="video/mp4">
      </video>
    </div>
  <!-- video section | consolidate_financials -->

  <?php require_once 'scripts.php'; ?>
  <script type="text/javascript" src="js/inner_page.js"></script>
</body>

</html>