  <div class="page_chairman outer_wrapper">
  	<div class="cont_left">
  		<div class="screentop_para">

        <div class="mask_a" style="width: 200%; height: 100%;">
          <div class="maskl bk_pink col2"></div>
          <div class="maskl bk_purple col3"></div>
          <div class="maskr bk_purple col5"></div>
        </div>

	  		<h1>
	  			<span class="h1 colr_white bk_pink" style="padding: 5px 15px 5px 15px;"> كلمة رئيس   </span> </h1>
	  		<h1>
	  			<span class="h1 colr_white"> مجلس إدارة  </span>
	  		</h1>
  		</div>
    	<img src="img/img_chairman.png" class="art1" />

      <a href="#" class="summary_btns bk_white" style="width: 220px; position: absolute; left: -35px; bottom: 50px; color: #4f0f8c;"> إلى كلمة الرئيس   <i></i> </a>
  	</div>
  	<div class="cont_right" style="min-height: 100vh;">
      <p class="colr_purple" style="font-size: 20px;position: absolute;top: 60%;left: 50%;width: 80%;transform: translate(-50%, -50%);">
        <img src="img/message.png" style="width: 50px;display: block;">
        حققت شركة الاتصالات السعودية (stc) خلال العام إنجازات مميزة، مكنتها من المضي قدماً إلى بُعد جديد في الخدمات الرقمية التي تثري حياة عملائنا وموظفينا، حيث تؤدي المجموعة دوراً محورياً في تمكين التحول الرقمي في المملكة العربية السعودية وفق رؤية المملكة العربية السعودية 2030 بالانسجام مع أهداف استراتيجية “تجرأ” للنمو في مسارات جديدة
      </p>
    </div>

    <div class="charimans_numbers">
      <div class="mask_a" style="width: 200%; height: 100%;">
        <div class="maskl bk_pink col2"></div>
        <div class="maskl bk_purple col3"></div>
        <div class="maskr bk_purple col5"></div>
      </div>
      <div class="ch_num_left">
        <table>
          <tr>
            <td> إجمالي   <br /> الربح  </td>
            <td> <span> 32,391 </span> <b> مليون ريال سعودي   </b> </td>
          </tr>
          <tr>
            <td> بإرتفاع  <br /> قدره  </td>
            <td> <span> 6.29% </span> </td>
          </tr>
        </table>
      </div>
      <div class="ch_num_right">
        <div>
          <p>
            مجموع ايرادات  
          </p>  
          <span> 40,259,106 </span> <b> مليون ريال سعودي  </b>
        </div>
      </div>
    </div>
  </div>