<!-- Banner start-->
  <div class="bk_purple financials_banner">
    <div class="page_financials outer_wrapper">
      <div class="cont_left">

        <div class="screentop_para">
          
          <div class="mask_a" style="width: 200%; height: 100%;">
            <div class="maskl bk_pink col2"></div>
            <div class="maskl bk_purple col3"></div>
            <div class="maskr bk_purple col5"></div>
          </div>

          <h1>
            <span class="h1 colr_white bk_pink" style="padding: 5px 15px 5px 15px;"> ملخص   </span> </h1>
          <h1>
            <span class="h1 colr_white"> ملخص    </span>
          </h1>
        </div>

        <!-- horizontal snippet -->
          <div class="horizontal_fBox snipit" style="/* display: none; */">

            <div class="mask_a" style="width: 200%; height: 100%;">
              <div class="maskl bk_pink col2"></div>
              <div class="maskl bk_purple col3"></div>
              <div class="maskr bk_purple col5"></div>
            </div>

            <div class="snipit_img">
                <img src="img/icons/icon_a.png" alt="">
            </div>
            <div class="snipit_text">
              <p>
                صافي الربح 
              </p>
            </div>
            <div class="snipit_price">
              <span>
                10,665
                <b>مليون ريال سعودي  </b>
              </span> 
            </div>
          </div>
        <!-- horizontal snippet -->
        <!-- horizontal snippet bar start -->
        <div class="snippetBar">
            <div class="sB-right-wrap">
              <div class="colr_white r-wrap-top">
                ‫صول‬ ‫ا‬ ‫إجمالي‬ ‫حجم‬
              </br>سعودي‬ ‫ريال‬ ‫مليون‬
              </div>
              <div class="r-wrap-bottom">
                  <div class="r-wrap-bottom-bar">&nbsp;</div>
              </div>
            </div>

            <div class="sB-left-wrap">
                <div class="l-wrap-inr bk_purple2">
                  <div class="colr_white l-wrap-inr-l">118,326‬‬</div>
                  <div class="l-wrap-inr-c bk_purple">
                  <div class="l-wrap-inr-c-front" style="width:30%;">&nbsp;</div>
                  </div>
                  <div class="colr_white l-wrap-inr-r">2019</div>
                </div>

                <div class="l-wrap-inr bk_pink">
                  <div class="colr_white l-wrap-inr-l">109,371</div>
                  <div class="l-wrap-inr-c bk_purple">
                  <div class="l-wrap-inr-c-front" style="width:60%;">&nbsp;</div>
                  </div>
                  <div class="colr_white l-wrap-inr-r">‫‪2018</div>
                </div>
            </div>
        </div>
        <!-- horizontal snippet bar end-->

        <!-- horizontal snippet -->
          <div class="horizontal_fBox snipit">

            <div class="mask_a" style="width: 200%; height: 100%;">
              <div class="maskl bk_pink col2"></div>
              <div class="maskl bk_purple col3"></div>
              <div class="maskr bk_purple col5"></div>
            </div>

            <div class="snipit_img">
                <img src="img/icons/icon_c.png" alt="">
            </div>
            <div class="snipit_text">
              <p>
                حجم إجمالي الأصول  118,326 مليون ريال سعودي في نهاية عام 2019م  
              </p>
            </div>
            <div class="snipit_price">
              <span>
                8.19%
                <b> بإرتفاع قدره  </b>
              </span>
            </div>
          </div>
        <!-- horizontal snippet -->

        <!-- horizontal snippet -->
          <div class="horizontal_fBox snipit" style="/* display: none; */">

            <div class="mask_a" style="width: 200%; height: 100%;">
              <div class="maskl bk_pink col2"></div>
              <div class="maskl bk_purple col3"></div>
              <div class="maskr bk_purple col5"></div>
            </div>

            <div class="snipit_img">
                <img src="img/icons/icon_b.png" alt="">
            </div>
            <div class="snipit_text">
              <p>
                بلغ الربح قبل الاستهلاك والإطفاء والفوائد والزكاة والضرائب (EBITDA) لعام 2019م 21,265 مليون ريال سعودي  
              </p>
            </div>
            <div class="snipit_price">
              <span>
                <b> بإرتفاع قدره  </b>
              </span> 
            </div>
          </div>
        <!-- horizontal snippet -->

        <!-- <p class="footer should_split">Total profit reached <b>SR 30,546 million</b> with an increase of<b>6.9%</b>, while operational profit reached <b>SR 12,245 million</b> at an increase of <b>11.5%</b>, Net profit increased by <b>7.6%</b>.</p> -->
      </div>

      <div class="cont_right" style="overflow: visible;">
        <div class="mask_a_vertical" style="width: calc( 100% + 200px ); height: 200%; right: -200px;">
          <div class="maskl bk_purple col10" style="height: 50%;"></div>
          <div class="maskl bk_white col10" style="height: 30%;"></div>
          <div class="maskr bk_pink col10" style="height: 20%;"></div>
        </div>
        <!-- <div class="mask_a" style="width: 200%; height: 100%;">
          <div class="maskl bk_purple col2"></div>
          <div class="maskl bk_purple col3"></div>
          <div class="maskr bk_purple col5"></div>
        </div> -->
        <p class="colr_purple col7 should_split">بلغ صافي الربح لعام 2019م مبلغ 10,665 مليون ريال سعودي مقابل 10,780 مليون ريال سعودي لعام 2018م وذلك بانخفاض قدره (1.07%)، وبلغت ربحية السهم لعام 2019م 5.33 ريال سعودي مقابل 5.39 ريال سعودي لعام 2018م. بلغ إجمالي الربح لعام 2019م مبلغ 32,391 مليون ريال سعودي مقابل 30,473 مليون ريال سعودي لعام 2018م وذلك بإرتفاع قدره 6.29% ، كما بلغ الربح التشغيلي لعام 2019م مبلغ 12,480 مليون ريال سعودي مقابل 12,245 مليون ريال سعودي لعام 2018م وذلك بإرتفاع قدره 1.92%.</p>

        <div class="mid_sect">
          <!-- vertical snippet -->
          <div class="snippet_wrapper vertical">
            <div>
              <img src="img/icons/icon_a.png" alt="">
            </div>
            <div>
              <p> نسبة السعودة في الشركة  </p>
            </div>
            <div>
              <span> 90.8% </span>
            </div>
          </div>
        <!-- vertical snippet -->

          <div class="wrapper-fa">
            <div class="bx1">
              <img src="img/icons/icon_d.png" />
            </div>
            <div class="horizontal_fBox snipit no_icon" style="margin: 50px 0 0 -80px">
              <div class="snipit_img">
                  <img src="img/icons/icon_a.png">
              </div>
              <div class="snipit_text">
                <p>
                  بلغت حقوق مساهمي الشركة 
                </p>
              </div>
              <div class="snipit_price">
                <span class="colr_purple">
                  61,763
                <!-- <b class="colr_purple">Million</b> -->
                </span> 
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
  <!-- Banner End-->