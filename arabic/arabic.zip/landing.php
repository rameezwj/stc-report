<div class="page_landing outer_wrapper">
	<div class="screenContent1">
		<div class="screentop_para">
			<div class="mask_a mask_reveal_para" style="width: 200%; height: 100%;">
				<div class="maskl bk_pink col2"></div>
				<div class="maskl bk_white col3"></div>
				<div class="maskr bk_purple col5"></div>
			</div>
			<h1> <span class="landingH1 txt_upper xhover-this colr_white"> Pushing the </span> </h1>
			<h1> <span class="landingH1 txt_upper xhover-this colr_white"> Boundaries </span> </h1>
			<h1> <span class="landingH1 txt_upper xhover-this colr_white"> towards the </span> </h1>
			<h1> <span class="landingH1 txt_upper xhover-this colr_white bk_pink" style="padding: 5px 50px 5px 15px;"> Future </span> </h1>
		</div>
	</div>

	<div class="boxes_1">
		<div style="border: 1px solid #ff375eb5; position: relative; top: 1px; left: 1px;">
			<div class="masking lImg1">
				<img src="img/img1.jpg" />
			</div>
		</div>
		<div>
			<div class="masking lImg2">
				<img src="img/img2.jpg" />
			</div>
		</div>
		<div style="border: 1px solid #ffffff87; position: relative; top: 1px; left: -1px;">
			<div class="masking lImg3">
				<img src="img/img3.jpg" />
			</div>
			
			<div class="lImg_icon_wrapper">
				<img class="lImg3_icon1" src="img/lImg3_icon1.png" />
				<img class="lImg3_icon2" src="img/lImg3_icon2.png" />
				<img class="lImg3_icon3" src="img/lImg3_icon3.png" />
				<div style="width: 80vw; height: 10px; position: relative; left: -50%;" class="bk_pink">
					<span style="position: absolute; width: 10px; height: 100%; display: block;" class="bk_white"></span>
					<p style="position: absolute; top: -115px; font-size: 30px; color: #fff; left: 150px;"> annual report <br /> 2019 </p>
				</div>
				<img class="lImg3_icon4" src="img/lImg3_icon4.png" />
			</div>
		</div>
		<div></div>
		<div style="border: 1px solid #9253cee3;"></div>
		<div>
			<div class="masking lImg4">
				<img src="img/img4.jpg" />
			</div>
		</div>
	</div>

	<div class="boxes_1" style="z-index: 10; pointer-events: none;">
		<div style="border: 1px solid #ff375eb5; position: relative; top: 1px; left: 1px;"></div>
		<div></div>
		<div style="border: 1px solid #ffffff87; position: relative; top: 1px; left: -1px;">
		</div>
		<div></div>
		<div style="border: 1px solid #9253cee3;"></div>
		<div></div>
	</div>

	<div class="logo_stc">
		<img src="img/stc_logo.png" />
	</div>
</div>