<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Place favicon.ico in the root directory -->

  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="font/stc_fonts.css">
  <!-- <link rel="stylesheet" href="fonts/fonts.css"> -->
  <link rel="stylesheet" href="css/swiper.min.css">
  <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
  <link rel="stylesheet" href="css/kursor.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link href="https://vjs.zencdn.net/7.7.5/video-js.css" rel="stylesheet" />


  <style type="text/css"></style>
</head>