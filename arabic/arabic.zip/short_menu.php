<div class="short_menu xtopView">
	<ul>
		<li class="xmasking sm_menu bk_white" id="btn_reveal_mmenu"> <a class="hover-this" href="javascript: void(0)"> &nbsp; </a> </li>
		<li class="xmasking sm_home"> <a class="hover-this" href="javascript: void(0)"> &nbsp; </a> </li>
		<li class="xmasking sm_download"> <a class="hover-this" href="javascript: void(0)"> &nbsp; </a> </li>
		<li class="xmasking sm_lang"> <a class="hover-this" href="javascript: void(0)"> &nbsp; </a> </li>
		<li class="xmasking nav_right"> <a class="hover-this" href="javascript: void(0)"> &nbsp; </a> </li>
		<li class="xmasking nav_left"> <a class="hover-this" href="javascript: void(0)"> &nbsp; </a> </li>
	</ul>

	<p> <span> stc.com.sa </span> </p>
</div>