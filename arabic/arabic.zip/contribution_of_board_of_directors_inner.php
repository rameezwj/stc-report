<!doctype html>
<html class="no-js" lang="">

<?php require_once 'head.php'; ?>

<body class="page_inner">
  <?php
    require_once 'menu_screen.php';
    require_once 'short_menu.php';
    require_once 'vwipes_loader.php';
  ?>
  <style type="text/css">
    /*page_creation_bod_a*/
    .page_creation_bod_a .screentop_para{
      margin: 50px 50px 50px 0;
      overflow: hidden;
      display: inline-block;
      position: relative;
    }
    .page_creation_bod_a .tabular_data{
      width:calc( 100% - 100px );
      margin: 0 auto;
      clear: both;
    }
    .page_creation_bod_a .tabular_data .c_row{
     display: flex;
    }
    .page_creation_bod_a .tabular_data .c_row div{
      flex: 1;
      padding: 40px;
      width: calc( 100% / 8 );
      text-align: right;
      color: #4f0f8c;
      border: 1px solid #4f0f8c;
      border-left: none;
      display: inline-flex;
      word-break: break-word;
      align-items: center;
      border-bottom: none;
      transition: all 0.2s ease-in;
    }
    .page_creation_bod_a .tabular_data .c_row div:last-child{
      border-left: 1px solid #4f0f8c;
    }
    .page_creation_bod_a .tabular_data .c_row:last-child div{
      border-bottom: 1px solid #4f0f8c; 
    }
    .page_creation_bod_a .tabular_data .tabular_data_inner .c_row:hover div:first-child{
      background: #FF375E;
    }
    .page_creation_bod_a .tabular_data .tabular_data_inner .c_row div:first-child{
      text-align: center;
      justify-content: center;
    }
    .page_creation_bod_a .tabular_data .tabular_data_inner .c_row:hover div{
      background: #4f0f8c;
      color: #fff;
    }
    .page_creation_bod_a .tabular_data .c_row.second div  {
      padding: 10px;
    }
    .page_creation_bod_a .tabular_data .c_row.first {
      margin-bottom: 20px;
    }
    .page_creation_bod_a .tabular_data .c_row.first div{
      border:none;
      border-left: 1px solid #fff;
      color: #fff;
      padding: 20px;
      text-align: center;
      justify-content: center;
    }

    .page_creation_bod_a .tabular_data2{
      width:calc( 100% - 100px );
      margin: 0 auto;
      clear: both;
    }
    .page_creation_bod_a .tabular_data2 .c_row{
     display: flex;
    }

    .page_creation_bod_a .tabular_data2 .c_row.first.table_white div{
      color: #4f0f8c;
      border: 1px solid #4f0f8c;
      border-left: none;
      border-top: none;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first.table_white div.last div.c_row{
      border-left: 0 !important;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first.table_white div span{
      border-left: 1px solid #4f0f8c !important;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first.table_white div span:last-child{
      border-left: none !important;
    }
    .page_creation_bod_a .tabular_data2 .c_row div{
      flex: 1;
      padding: 40px;
      width: calc( 100% / 8 );
      text-align: right;
      color: #4f0f8c;
      border: 1px solid #4f0f8c;
      border-left: none;
      display: inline-flex;
      word-break: break-word;
      align-items: center;
      border-bottom: none;
      transition: all 0.2s ease-in;
    }
    .page_creation_bod_a .tabular_data2 .c_row div:last-child{
      border-left: 1px solid #4f0f8c !important;
    }
    .page_creation_bod_a .tabular_data2 .c_row:last-child div{
      border-bottom: 1px solid #4f0f8c; 
    }
    .page_creation_bod_a .tabular_data2 .tabular_data_inner .c_row:hover div:first-child{
      background: #FF375E;
    }
    .page_creation_bod_a .tabular_data2 .tabular_data_inner .c_row div:first-child{
      text-align: center;
      justify-content: center;
    }
    .page_creation_bod_a .tabular_data2 .tabular_data_inner .c_row:hover div{
      background: #4f0f8c;
      color: #fff;
    }
    .page_creation_bod_a .tabular_data2 .c_row.second div  {
      padding: 10px;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first {
      margin-bottom: 0;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first div{
      border:none;
      border-left: 1px solid #fff;
      color: #fff;
      padding: 20px;
      text-align: center;
      justify-content: center;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first div.last{
      padding: 0;
      flex-wrap: wrap;
      flex: 20%;
      align-items: initial;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first div.last .f-row{
      display: flex;
      flex: initial;
      flex-wrap: wrap;
      flex: 0 0 100%;
      border: none;
      padding: 0;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first div.last .f-row span{
      display: inline-flex;
      word-break: break-word;
      align-items: center;
      flex: 1;
      height: 100%;
       border-left: 1px solid #fff; 
       border-top: 1px solid #fff; 
      width: 50%;
      justify-content: center;
      padding: 10px 20px;
    }
    .page_creation_bod_a .tabular_data2 .c_row.first div.last .f-row span:last-child{
       border-left: none !important;
    }
    .page_creation_bod_a .img_wrap {
      position: relative;
      overflow: hidden;
    }
    .page_creation_bod_a .img_wrap .left{
      width: 40%;
      float: left;

    }
    .page_creation_bod_a .img_wrap .right{
      width: 35%;
      float: right;
    }
    .page_creation_bod_a .img_wrap img{
      width: 100%;
    }
    .page_creation_bod_a .cwrapper{
        margin-bottom:50px;
    }
    .page_creation_bod_a .bar-wrap{
      position: relative;
      height: 10px;
      width: 100%;
      margin-bottom: 50px;
    }
   
   .page_creation_bod_a .sp_wrap .content-wrapper {
      position: relative;
      /*margin: 50px 0;*/
    }
    .page_creation_bod_a .sp_wrap .content-wrapper.c-row-reverse .left{
      width: 50%;
      float: right;
    }
    .page_creation_bod_a .sp_wrap .content-wrapper.c-row-reverse .left .box_center_content{
      float: right;
      width: 90%;
    }
    .page_creation_bod_a .sp_wrap .content-wrapper.c-row-reverse .right{
    }
    .page_creation_bod_a .sp_wrap .content-wrapper:after {
      content: '';
      display: table;
      clear: both;
    }
    .page_creation_bod_a .sp_wrap .content-wrapper .left{
      width: 50%;
      float: left;
      position: relative;
      min-height: 250px;
    }
    .page_creation_bod_a .sp_wrap .content-wrapper .left .box_center_content{
        /*margin:0 auto;*/
        width: 80%;
        min-height: 400px;
        /*float: left;*/
    }

    .page_creation_bod_a .sp_wrap .content-wrapper .left .box_center_content p{
      font-size: 28px;
      line-height: 38px;
      font-family: "stc_light";
    }
    .page_creation_bod_a .sp_wrap .content-wrapper .img-wrap{
      height: 400px;
    }
    .page_creation_bod_a .sp_wrap .content-wrapper .img-wrap img{
      height: 100%;
      width: 100%;
      object-fit: cover;
      object-position: top right;
    }
    .page_creation_bod_a .sp_wrap .content-wrapper .right{
      width: 40%;
      float: right;
      position: relative;
      min-height: 250px;
    }
   .page_creation_bod_a .sp_wrap .sp_row{
        display: flex;
        margin:50px 0;
   }
   .page_creation_bod_a .sp_wrap .sp_row .left,
   .page_creation_bod_a .sp_wrap .sp_row .right{
    flex: initial;
   }
  .page_creation_bod_a .sp2_row .left,
  .page_creation_bod_a .sp2_row .right{
    height: 400px;
  }
  .page_creation_bod_a .sp2_row .right
  {
    height: 400px;
    padding: 40px;
    width: 45%;
  }
  .page_creation_bod_a .sp_wrap .sp_row .right .content_para{
    margin-bottom: 0;
  }
  .page_creation_bod_a .sp_wrap .bar-wrap {
    position: absolute;
    height: 60px;
    width: 80%;
    top: 50%;
    right: 0;
    transform: translate(0,-100%);
  }
 /*page_creation_bod_a*/

 
    /*HELPER CLASSES*/
    .marginr50{
    margin-right: 50px;
    }
    .nopadding{
    padding: 0 !important;
    }
    .noheight{
    height: auto !important;
    min-height: auto !important;
    max-height: auto !important;
    }
    .nomargin{
    margin: 0 !important;
    }
    .txt_vertical
    {
      writing-mode: vertical-lr;
    }
    /*HELPER CLASSES*/

    /*HELPER CLASSES*/
    .marginr50{
    margin-right: 50px;
    }
    .nopadding{
    padding: 0 !important;
    }
    .noheight{
    height: auto !important;
    min-height: auto !important;
    max-height: auto !important;
    }
    .nomargin{
    margin: 0 !important;
    }
    /*HELPER CLASSES*/

  </style>
<div class="main_boc">
    <div class=" outer_wrapper">
    <!-- SECTION1 -->
      <div class="page_creation_bod_a">
         <div class="cwrapper">
          <div class="screentop_para">
            <h1>
              <span class="h1 colr_white bk_purple" style="padding: 5px 15px 5px 150px;"> ‫
              ‫مشاركة الأعضاء في 
              </span> 
            </h1>
            <h1>
              <span class="h1 colr_purple"> 
             ‫‫ اجتماعات المجلس واللجان 
              </span>
          </h1>
          </div>
          <div class="img_wrap">
            <div class="right marginr50" style="width: 40%;">
             <p class="content_para">
             أولاً: تُبين الجداول التالية عدد اجتماعات مجلس الإدارة واللجان للدورة السابعة، وحضور الأعضاء لتلك الاجتماعات خلال عام 2019م، على النحو التالي : 
             </p>
             <br><br>
             <b class="content_para">‫اجتماعات مجلس الإدارة </b>
              <p class="content_para">
              ‫‫عقد مجلس الإدارة خمسة اجتماعات، ويبين الجدول التالي عدد اجتماعات المجلس خلال عام 2019م، وحضور الأعضاء لتلك الاجتماعات.
             </p>
            </div>
          </div>
          <!-- <div class="tabular_data2 margint50">
            <div class="c_row first bk_purple">
             <div>‫م‬</div>
             <div>‫‫‫سم‬ ‫ا‬</div>
             <div>‫المنصب‬</div>
             <div class="c_row last">
               <div class="c_row f-row" style="padding:10px 20px;">‫‫مقرها‬</div>
               <div class="c_row f-row">
                 <span>‫‪‫‪20‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪21‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪15‬‬ ‫مايو‬</span>
                 <span>‫‪‫‪18‬‬ ‫سبتمبر‬</span>
                 <span>‫‪‫‪18‬‬ ‫ديسمبر‬</span>
               </div>
             </div>
             <div>‫المجموع‬</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              1
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫
             </div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              2
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              3
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              4
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              5
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              6
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              7
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              8
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              9
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
          </div> -->
          <div class="ctable_wrapper">
            <table class="stc_table">
                <tbody>
                  <tr>
                    <td rowspan="3">
                      <p><strong>م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>الاسم</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المنصب</strong></p>
                    </td>
                    <td>&nbsp;</td>
                    <td colspan="4">
                      <p><strong>دورة المجلس السابعة عام 2019م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المجموع</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><strong>7</strong></p>
                    </td>
                    <td>
                      <p><strong>8</strong></p>
                    </td>
                    <td>
                      <p><strong>9</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>20 مارس</strong></p>
                    </td>
                    <td>
                      <p><strong>21 مارس</strong></p>
                    </td>
                    <td>
                      <p><strong>15 مايو</strong></p>
                    </td>
                    <td>
                      <p><strong>18 سبتمبر</strong></p>
                    </td>
                    <td>
                      <p><strong>18 ديسمبر</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>1</strong></p>
                    </td>
                    <td>
                      <p><span">صاحب السمو الملكي الأمير/ محمد بن خالد العبدالله الفيصل</span></p>
                    </td>
                    <td>
                      <p><span">رئيس مجلس الإدارة</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>2</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور/ خالد بن حسين بياري</span></p>
                    </td>
                    <td>
                      <p><span">نائب رئيس مجلس الإدارة</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>3</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ محمد بن طلال النحاس</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>4</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ راشد بن ابراهيم شريف</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ سانجاي كابور</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ روي تشـســنـــــــــــات</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>7</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور/ إبراهيم بن عبدالرحمن القاضي</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">&times;</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">4</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>8</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ أسامة بن ياسين الخياري</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>9</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ أحمد بن محمد العمران</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                </tbody>
            </table>
          </div>
          <div class="sp_wrap margint50">
            <div class="content-wrapper ">
              <div class="left">
               <div class="img-wrap">
                 <img src="img/planning.png">
               </div>
              </div>
              <div class="right marginr50">
              <h5 class="h5 colr_purple">
              ‫‫اجتماعات لجان مجلس الإدارة   
              </h5>
               <p class="content_para">
                ‫‫وفقاً للائحة حوكمة stc، والأنظمة واللوائح الصادرة من الجهات ذات العلاقة، يشكل المجلس اللجان اللازمة لتأدية عمله بما يحقق كفاءة وفاعلية المجلس، ويراعى عند تشكيل اللجان تحديد مسؤولياتها، وإجراءات عملها، من قبل المجلس وتوثيق هذه المسؤوليات والإجراءات، وإصدار القرارات اللازمة لذلك، وتعريف ذوي العلاقة بها على نحو مناسب. وقد شُكلت لجان المجلس للدورة الحالية (السابعة) على النحو التالي:
               </p>
               <br><br>
               <h5 class="h5 colr_purple">
               اللجنة التنفيذية:     
               </h5>
               <p class="content_para">
                ‫‫‫تتكون اللجنة من أربعة أعضاء من أعضاء مجلس الإدارة، وعضوين خارجيين أحدهما الرئيس التنفيذي للشركة، وتختص اللجنة بمراجعة الاستراتيجيات والموازنات السنوية التقديرية والأعمال المحلية والدولية للشركة في مجالات العمل الأساسية وغير الأساسية، والموافقة عليها بحسب الصلاحيات المنوطة بها والمحددة من قبل مجلس الإدارة، وقد عقدت اللجنة ستة اجتماعات خلال عام 2019م، كما هو موضح في الجدول التالي:
               </p>
              </div>
            </div>
          </div>
          <!-- <div class="tabular_data2 margint50">
            <div class="c_row first bk_purple">
             <div>‫م‬</div>
             <div>‫‫‫سم‬ ‫ا‬</div>
             <div>‫المنصب‬</div>
             <div class="c_row last">
               <div class="c_row f-row" style="padding:10px 20px;">‫‫مقرها‬</div>
               <div class="c_row f-row">
                 <span>‫‪‫‪20‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪21‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪15‬‬ ‫مايو‬</span>
                 <span>‫‪‫‪18‬‬ ‫سبتمبر‬</span>
                 <span>‫‪‫‪18‬‬ ‫ديسمبر‬</span>
               </div>
             </div>
             <div>‫المجموع‬</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              1
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫
             </div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              2
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              3
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              4
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              5
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              6
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              7
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              8
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              9
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
          </div> -->

          <div class="ctable_wrapper">
              <table class="stc_table">
                <tbody>
                  <tr>
                    <td rowspan="3">
                      <p><strong>م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>الاسم</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المنصب</strong></p>
                    </td>
                    <td colspan="6">
                      <p><strong>دورة المجلس السابعة عام 2019م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المجموع</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>4</strong></p>
                    </td>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><strong>7</strong></p>
                    </td>
                    <td>
                      <p><strong>8</strong></p>
                    </td>
                    <td>
                      <p><strong>9</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>14 يناير</strong></p>
                    </td>
                    <td>
                      <p><strong>19 فبراير</strong></p>
                    </td>
                    <td>
                      <p><strong>7 مايو</strong></p>
                    </td>
                    <td>
                      <p><strong>12 سبتمبر</strong></p>
                    </td>
                    <td>
                      <p><strong>3 نوفمبر</strong></p>
                    </td>
                    <td>
                      <p><strong>3 ديسمبر</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>1</strong></p>
                    </td>
                    <td>
                      <p><span">صاحب السمو الملكي الأمير/ محمد بن خالد العبدالله الفيصل</span></p>
                    </td>
                    <td>
                      <p><span">رئيس اللجنة</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">6</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>2</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور/ خالد بن حسين بياري</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">6</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>3</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ سانجاي كابور</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">6</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>4</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور/ إبراهيم بن عبدالرحمن القاضي&nbsp;</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">6</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ سلطان بن عبدالملك آل الشيخ</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">6</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><span">المهندس/ ناصر بن سليمان الناصر</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">6</span></p>
                    </td>
                  </tr>
                </tbody>
              </table>
          </div>


          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
              <div class="right marginr50" style="position: relative; width: 50%;">
                <h5 class="h5 colr_purple">
                 ‫‫لجنة الترشيحات والمكافآت:        
                 </h5>
                 <p class="content_para">
                  ‫‫‫تتكون اللجنة من عضوين من أعضاء مجلس الإدارة، وعضوين خارجيين وتختص اللجنة بمراجعة عملية تصميم آلية التشغيل الملائمة والمصادقة عليها وإقرارها، ووضع ومراجعة هيكل الرواتب بما يتناسب مع معايير وتطورات السوق، وتطبيقها تطبيقاً عادلاً بما يؤمّن الحوافز اللازمة للإدارة والموظفين للقيام بالدور المطلوب، ومراجعة هيكل مجلس الإدارة ورفع التوصيات لمجلس الإدارة بشأن التغييرات التي يمكن إجراؤها، والتأكد بشكل سنوي من استقلالية الأعضاء المستقلين وعدم وجود أي تعارض مصالح خصوصاً إذا كان العضو يشغل عضوية مجلس إدارة شركة أخرى، وكذلك مراجعة سياسة المميزات والتعويضات لمجلس الإدارة والمصادقة عليها تمهيداً لإحالتها إلى مجلس الإدارة، والتأكد من أن أعمال stc تتماشى مع أفضل الممارسات في مجال الحوكمة، وقد عقدت اللجنة أربعة اجتماعات خلال عام 2019م، كما هو موضح في الجدول التالي:
                </p>
              </div>
              <div class="left">
                <div class="bar-wrap" style="left: 0;right: auto;height: 25px;">
                    <div class="element_bars_hr" style="width: 80%;position: absolute;left: 0;height: 100%;">
                        <div class="leftbar bk_pink" style="width: 5%"></div>
                        <div class="rightbar  bk_purple" style="width: 95%"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- <div class="tabular_data2 margint50">
            <div class="c_row first bk_purple">
             <div>‫م‬</div>
             <div>‫‫‫سم‬ ‫ا‬</div>
             <div>‫المنصب‬</div>
             <div class="c_row last">
               <div class="c_row f-row" style="padding:10px 20px;">‫‫مقرها‬</div>
               <div class="c_row f-row">
                 <span>‫‪‫‪20‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪21‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪15‬‬ ‫مايو‬</span>
                 <span>‫‪‫‪18‬‬ ‫سبتمبر‬</span>
                 <span>‫‪‫‪18‬‬ ‫ديسمبر‬</span>
               </div>
             </div>
             <div>‫المجموع‬</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              1
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫
             </div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              2
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              3
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              4
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              5
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              6
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              7
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              8
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              9
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
          </div> -->

          <div class="ctable_wrapper">
              <table class="stc_table">
                <tbody>
                  <tr>
                    <td rowspan="3">
                      <p><strong>م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>الاسم</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المنصب</strong></p>
                    </td>
                    <td colspan="4">
                      <p><strong>دورة المجلس السابعة عام 2019م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المجموع</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><strong>7</strong></p>
                    </td>
                    <td>
                      <p><strong>8</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>6 مارس</strong></p>
                    </td>
                    <td>
                      <p><strong>2 مايو</strong></p>
                    </td>
                    <td>
                      <p><strong>10 سبتمبر</strong></p>
                    </td>
                    <td>
                      <p><strong>5 ديسمبر</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>1</strong></p>
                    </td>
                    <td>
                      <p><span>الأستاذ/ أسامة بن ياسين الخياري</span></p>
                    </td>
                    <td>
                      <p><span>رئيس اللجنة</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>4</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>2</strong></p>
                    </td>
                    <td>
                      <p><span>الأستاذ/ احمد بن محمد العمران</span></p>
                    </td>
                    <td>
                      <p><span>عضو</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>4</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>3</strong></p>
                    </td>
                    <td>
                      <p><span>الأستاذ/ جون براند</span></p>
                    </td>
                    <td>
                      <p><span>عضو</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>4</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>4</strong></p>
                    </td>
                    <td>
                      <p><span>الأستاذة/ هدى بنت محمد الغصن</span></p>
                    </td>
                    <td>
                      <p><span>عضو</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>✔</span></p>
                    </td>
                    <td>
                      <p><span>4</span></p>
                    </td>
                  </tr>
                </tbody>
              </table>
          </div>


          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">

              <div class="right marginr50 noheight" style="position: relative; width: 50%;">
                <h5 class="h5 colr_purple">
                ‫لجنة المراجعة:    
                 </h5>
                 <p class="content_para">
                 ‫وافقت الجمعية العامة على تشكيل لجنة المراجعة، لدورة المجلس السابعة، تبدأ من 7/6/2018م. وعلى مهامها وضوابط عملها، ومكافآت أعضائها، وتتكون اللجنة من عضو مجلس إدارة، وثلاثة أعضاء خارجيين مختصين بالشؤون المالية والمحاسبية وأعمال المراجعة، وحيث قدم استقالته عضو لجنة المراجعة الدكتور/ خالد الفداغ من عضوية اللجنة وذلك لظروفه الشخصية، وبدأ سريان الاستقالة بتاريخ 6/12/1440هـ (الموافق 7/8/2019م)، ونُشر إعلان الاستقالة في موقع السوق المالية السعودية (تداول) بتاريخ 6/8/2019م، فقد قرر المجلس في اجتماعه الثامن بتاريخ 19/1/1441هـ (الموافق 18/9/2019م)، تعيين كلٍ من الدكتور/ عمرو بن خالد كردي والمهندس/ طارق بن عبدالعزيز الرخيمي في لجنة المراجعة (عضوين خارجيين) حتى انتهاء مدة عمل دورة المجلس السابعة ورفع توصية للجمعية العامة للشركة في اجتماعها القادم للمصادقة، ونُشر إعلان التعيين في موقع تداول بتاريخ 19/1/1441هـ (الموافق 18/9/2019م)، وبالتالي تتكون اللجنة الآن من عضو مجلس إدارة، وأربعة أعضاء خارجيين. وتختص اللجنة بمراجعة السياسات والإجراءات المالية والإدارية للشركة، وإجراءات إعداد التقارير المالية ومخرجاتها، كما تطّلع اللجنة على تقارير وملحوظات المراجعة الداخلية، وتوصي لمجلس الإدارة بتعيين المحاسبين القانونيين وفصلهم وتحديد أتعابهم والتأكد من استقلاليتهم، ودراسة القوائم المالية الأولية والسنوية قبل عرضها على مجلس الإدارة وإبداء الرأي بشأنها، ودراسة ملحوظات المحاسب القانوني على القوائم المالية وكذلك دراسة خطة المراجعة مع المحاسب القانوني وإبداء ملحوظاتها عليها، وغيرها من الأعمال بصورة دورية ومنتظمة، وبما يمكنها من تقويم كفاءة وفاعلية الأنشطة الرقابية، وإدارة المخاطر، وضمان الالتزام، ومكافحة الاحتيال والفساد ، وقد عقدت اللجنة سبعة اجتماعات خلال عام 2019م، كما هو موضح في الجدول التالي:
                </p>
              </div>
            </div>
          </div>


          <!-- <div class="tabular_data2 margint50">
            <div class="c_row first bk_purple">
             <div>‫م‬</div>
             <div>‫‫‫سم‬ ‫ا‬</div>
             <div>‫المنصب‬</div>
             <div class="c_row last">
               <div class="c_row f-row" style="padding:10px 20px;">‫الفعلية‬ ‫الملكية‬ ‫نسبة‬</div>
               <div class="c_row f-row">
                 <span>‫‪‫‪20‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪21‬‬ ‫مارس‬</span>
                 <span>‫‪‫‪15‬‬ ‫مايو‬</span>
                 <span>‫‪‫‪18‬‬ ‫سبتمبر‬</span>
                 <span>‫‪‫‪18‬‬ ‫ديسمبر‬</span>
               </div>
             </div>
             <div>‫المجموع‬</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              1
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫
             </div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              2
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              3
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              4
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              5
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              6
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              7
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              8
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
            <div class="c_row first table_white">
             <div>‫
              9
             </div>
             <div>‫</div>
             <div>‫</div>
             <div class="c_row last">
               <div class="c_row f-row">
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
                 <span>‬</span>
               </div>
             </div>
             <div>‫</div>
            </div>
          </div> -->

          <div class="ctable_wrapper">
              <table class="stc_table">
                <tbody>
                  <tr>
                    <td rowspan="3">
                      <p><strong>م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>الاسم</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المنصب</strong></p>
                    </td>
                    <td colspan="7">
                      <p><strong>دورة المجلس السابعة عام 2019م</strong></p>
                    </td>
                    <td rowspan="3">
                      <p><strong>المجموع</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><strong>7</strong></p>
                    </td>
                    <td>
                      <p><strong>8</strong></p>
                    </td>
                    <td>
                      <p><strong>9</strong></p>
                    </td>
                    <td>
                      <p><strong>10</strong></p>
                    </td>
                    <td>
                      <p><strong>11</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>23 يناير</strong></p>
                    </td>
                    <td>
                      <p><strong>11 فبراير</strong></p>
                    </td>
                    <td>
                      <p><strong>7 مارس</strong></p>
                    </td>
                    <td>
                      <p><strong>22 أبريل</strong></p>
                    </td>
                    <td>
                      <p><strong>22 يوليو</strong></p>
                    </td>
                    <td>
                      <p><strong>22 أكتوبر</strong></p>
                    </td>
                    <td>
                      <p><strong>26 نوفمبر</strong></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>1</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور/ إبراهيم بن عبدالرحمن القاضي&nbsp;</span></p>
                    </td>
                    <td>
                      <p><span">رئيس اللجنة</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">7</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>2</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور / خالد بن داود الفداغ</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>
                      <p><span">5</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>3</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ خالد بن عبدالله العـنـقــري</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">7</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>4</strong></p>
                    </td>
                    <td>
                      <p><span">الأستاذ/ مـدحـت بن فــريـد تــوفــيـق</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">7</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>5</strong></p>
                    </td>
                    <td>
                      <p><span">الدكتور/ عمـرو بــن خـالـد كـردي</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">2</span></p>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <p><strong>6</strong></p>
                    </td>
                    <td>
                      <p><span">المهندس/ طـارق بن عبدالعزيز الـرخيمي</span></p>
                    </td>
                    <td>
                      <p><span">عضو</span></p>
                    </td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">✔</span></p>
                    </td>
                    <td>
                      <p><span">2</span></p>
                    </td>
                  </tr>
                </tbody>
              </table>
          </div>



          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
              <div class="left" style="position: relative;">
                <div class="bar-wrap" style="top: 0;transform: translate(0,0);height: 20px;width: 100%">
                   <div class="element_bars_hr" style="width: 100%;position: absolute;right: 0;height: 100%;">
                        <div class="leftbar bk_purple" style="width: 95%"></div>
                        <div class="rightbar bk_pink" style="width: 5%"></div>
                  </div>
                </div>
                <div class="img-wrap margint100 marginr50">
                  <img src="img/growth.png">
                </div>
                <div class="marginr50 margint100">
                  <h5 class="h5 colr_purple">
                  ‫لجنة الاستثمار:
                </h5>
                <p class="content_para">تتكون اللجنة من أربعة أعضاء من أعضاء مجلس الإدارة، وعضو خارجي وتختص اللجنة بمراجعة سياسة الاستثمارات وفق استراتيجيات stc، كما تراجع اللجنة وتدرس فرص الاستثمار الاستراتيجية والتوصية بالمناسب منها، وقد عقدت اللجنة أربعة اجتماعات خلال عام 2019م، كما هو موضح في الجدول التالي:</p>

                <!-- <div class="tabular_data nomargin col10" style="width: 100%;">
                  <div class="c_row first bk_purple nomargin">
                    <div>‫م‬</div>
                    <div>‫سم‬ ‫ا‬</div>
                    <div>‫الحضور‬</div>
                  </div>
                  <div class="tabular_data_inner">
                    <div class="c_row">
                      <div>1</div>
                      <div></div>
                      <div></div>
                    </div>
                    <div class="c_row">
                      <div>2</div>
                      <div></div>
                      <div></div>
                    </div>
                    <div class="c_row">
                      <div>3</div>
                      <div></div>
                      <div></div>
                    </div>
                    <div class="c_row">
                      <div>4</div>
                      <div></div>
                      <div></div>
                    </div>
                  </div>
                </div> -->

                <div class="ctable_wrapper">
                    <table class="stc_table">
                      <tbody>
                        <tr>
                          <td rowspan="3">
                            <p><strong>م</strong></p>
                          </td>
                          <td rowspan="3">
                            <p><strong>الاسم</strong></p>
                          </td>
                          <td rowspan="3">
                            <p><strong>المنصب</strong></p>
                          </td>
                          <td colspan="4">
                            <p><strong>دورة المجلس السابعة عام 2019م</strong></p>
                          </td>
                          <td rowspan="3">
                            <p><strong>المجموع</strong></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>4</strong></p>
                          </td>
                          <td>
                            <p><strong>5</strong></p>
                          </td>
                          <td>
                            <p><strong>6</strong></p>
                          </td>
                          <td>
                            <p><strong>7</strong></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>21 فبراير</strong></p>
                          </td>
                          <td>
                            <p><strong>8 مايو</strong></p>
                          </td>
                          <td>
                            <p><strong>15 سبتمبر</strong></p>
                          </td>
                          <td>
                            <p><strong>4 ديسبمر</strong></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>1</strong></p>
                          </td>
                          <td>
                            <p><span">صاحب السمو الملكي الأمير/ محمد بن خالد العبدالله الفيصل</span></p>
                          </td>
                          <td>
                            <p><span">رئيس اللجنة</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">4</span></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>2</strong></p>
                          </td>
                          <td>
                            <p><span">الأستاذ/ محمد بن طـلال النـحاس</span></p>
                          </td>
                          <td>
                            <p><span">عضو</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">4</span></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>3</strong></p>
                          </td>
                          <td>
                            <p><span">الأستاذ/ راشد بن ابراهيم شريف</span></p>
                          </td>
                          <td>
                            <p><span">عضو</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">4</span></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>4</strong></p>
                          </td>
                          <td>
                            <p><span">الأستاذ/ روي تشـســنـــــــــــات</span></p>
                          </td>
                          <td>
                            <p><span">عضو</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">4</span></p>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <p><strong>5</strong></p>
                          </td>
                          <td>
                            <p><span">الأستاذ/ مازن بن أحمد الجبير</span></p>
                          </td>
                          <td>
                            <p><span">عضو</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">✔</span></p>
                          </td>
                          <td>
                            <p><span">4</span></p>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                </div>


                <!-- <p class="content_para margint50">
                   ‫‫مسبقاً‬ ‫رتباطهما‬ ‫تشـســنـــــــــــات‪،‬‬ ‫روي‬ ‫ستاذ‪/‬‬ ‫وا‬ ‫كابـور‪،‬‬ ‫سانجـــاي‬ ‫ستاذ‪/‬‬ ‫ا‬ ‫حضور‬ ‫عدم‬ ‫‪.‬يعزى‬
                   <br>
                   <br>
                    ‫محا‬ ‫على‬ ‫ع‬ ‫ط‬ ‫ا‬ ‫يمكن‬ ‫‪stc‬‬ ‫لكتروني‬ ‫ا‬ ‫‪www.stc.com.sa‬‬
                    ‫موقع‬ ‫في‬ ‫جتماعات‬ ‫ا‬
                </p> -->

                </div>
              </div>
              <div class="right marginr50">
                <h5 class="h5 colr_purple">
                  ‫بيان بتواريخ الجمعيات العامة للمساهمين المنعقدة خلال السنة المالية 2019م وأسماء أعضاء المجلس الحاضرين لهذه الجمعيات:             
                </h5>
                <p class="content_para">
                أولاً: الجمعية العامة غير العادية بتاريخ 24/4/2019م
                <br><br>
                ‫‫عُقد اجتماع الجمعية العامة غير العادية في مقر stc الرئيس بالرياض، بتاريخ 19/8/1440هـ (الموافق 24/4/2019م)، وجرى نشر نتائجه، في موقع تداول في اليوم التالي بتاريخ 25/4/2019م، وكانت نتائج التصويت على جدول أعمال الجمعية على النحو التالي: 
                <br><br>
                ‫‫الموافقة على تقرير مجلس الإدارة عن السنة المالية المنتهية في 31/12/2018م.
                <br><br>
                ‫الموافقة على تقرير مراجع حسابات stc للسنة المالية المنتهية في 31/12/2018م.
                <br><br>
                ‫الموافقة على القوائم المالية الموحدة للشركة للسنة المالية المنتهية في 31/12/2018م.
                <br><br>
                الموافقة على تعيين مكتب ارنست ويونغ وشركاهم (‏محاسبون قانونيون‏)‏ مراجع الحسابات الخارجي للشركة من بين المرشحين بناءً على توصية لجنة المراجعة
                <br><br>
                ‫‫الموافقة على سياسة توزيع الأرباح للشركة لفترة السنوات الثلاث القادمة بداية من الربع الرابع من عام 2018م.
                <br><br>
                ‫‫الموافقة على توصية مجلس الإدارة بتوزيعات إضافية لمرة واحدة عن عام ‏‏2018م بمبلغ مقداره 4.000 مليون ريال سعودي ‏بواقع 2 ريال سعودي عن كل سهم، وستكون ‏أحقية توزيعات الأرباح للمساهمين المالكين ‏للأسهم المسجلين لدى مركز إيداع الأوراق المالية ‏بنهاية ثاني يوم تداول يلي يوم انعقاد الجمعية ‏العامة للشركة، وتقرر أن يتم التوزيع للأسهم المستحقة للتوزيعات والتي تبلغ 2,000 مليون سهم في تاريخ 11/9/1440هـ الموافق 16/5/2019م وذلك حسب ما تم الإعلان عنه مسبقاً. 
                <br><br>
                ‫الموافقة على تعديل المادة رقم (16)، الفقرة (ب) من النظام الأساس للشركة، المتعلقة بالسندات والصكوك لتكون: "يجوز للشركة - بقرار من مجلس الإدارة - ووفقاً لنظام السوق المالية والأنظمة واللوائح الأخرى ذات العلاقة، إصدار أي نوع من أنواع أدوات الدين القابلة للتداول سواء بالعملة السعودية او غيرها، داخل المملكة أو خارجها، كالسندات والصكوك، سواء أصدرت تلك الأدوات في الوقت نفسه أو من خلال سلسلة من الإصدارات أو من خلال برنامج أو أكثر يضعه مجلس الإدارة من وقت إلى آخر، وكل ذلك في الأوقات وبالمبالغ ووفقاً للشروط التي يقرها مجلس إدارة stc ، وله حق اتخاذ جميع الإجراءات اللازمة في ذلك".
                <br><br>
                ‫‫الموافقة على تعديل المادة رقم (29)، الفقرة رقم (2) من النظام الأساس للشركة، المتعلقة بالدعوة لانعقاد الجمعية العامة، لتكون المدة قبل 21 يوماً على الأقل.
                <br><br>
                ‫الموافقة على تعديل المادة رقم (40)، من النظام الأساس للشركة، المتعلقة بإيداع نسخ كافية من تقرير مدى كفاية نظام الرقابة الداخلية في الشركة، في مركز الشركة الرئيس، تحت تصرف المساهمين، لتكون المدة قبل 21 يوماً على الأقل قبل موعد انعقاد الجمعية العامة.
                <br><br>
                 <br><br>
                ‫الموافقة على تعديل المادة رقم (44)، الفقرة رقم (2)، من النظام الأساس للشركة، المتعلقة بإيداع نسخٍ من القوائم المالية للشركة وتقرير عن نشاطها ومركزها المالي عن السنة المنقضية، في مركز الشركة الرئيس، تحت تصرف المساهمين، لتكون المدة قبل 21 يوماً على الأقل من موعد انعقاد الجمعية العامة.
                <br><br>
                 <br><br>
                ‫الموافقة على تعديل سياسة ترشيح أعضاء مجلس الإدارة ومكافآتهم، ومكافآت اللجان المنبثقة، ومكافآت الإدارة التنفيذية.
                <br><br>
                 <br><br>
                ‫الموافقة على تعديل لائحة عمل لجنة الترشيحات والمكافآت.
                <br><br>
                  <br><br>
                ‫الموافقة على تعديل لائحة عمل لجنة المراجعة، وعلى مهامها وضوابط عملها، ومكافآت أعضائها. 
                <br><br>
                  <br><br>
                ‫الموافقة على المكافآت والتعويضات المدفوعة لأعضاء مجلس الإدارة نظير عضويتهم والمضمنة في تقرير مجلس الإدارة للفترة من 1 يناير 2018م وحتى 31 ديسمبر 2018م.
                <br><br>
                  <br><br>
                ‫الموافقة على قيام الشركة بإنشاء برنامج صكوك دولية وطرح صكوك بموجبه بشكل مباشر أو عن طريق تأسيس منشأة ذات غرض خاص يتم إنشاؤها واستخدامها لإصدار صكوك أولية أو ثانوية في جزء أو عدة أجزاء أو مرحلة أو عدة مراحل، أو من خلال سلسلة من الإصدارات بموجب برنامج الصكوك هذا، بالدولار الأمريكي، بما لا يتجاوز مبلغاً وقدره 5.000 مليون دولار أمريكي، لإجمالي قيمة إصدارات وأجزاء برنامج الصكوك المشار إليه أعلاه في أي وقت من الأوقات، وذلك بالمبالغ والتوقيت والمدد والشروط والتفاصيل الأخرى التي يوافق عليها مجلس الإدارة من حين لآخر، وللمجلس في سبيل ذلك اتخاذ كافة التصرفات والإجراءات اللازمة لتأسيس البرنامج وإصدار الصكوك بموجبه، ومنح المجلس حق تفويض أي أو كل من تلك الصلاحيات لأي شخص أو أشخاص آخرين وإعطائهم حق تفويض الغير.
                <br><br>
                </p>
              </div>
            </div>
          </div>


          <div class="ctable_wrapper">
            <h5 class="h5 colr_purple"> 
               أسماء الأعضاء الحاضرين لاجتماع الجمعية كالتالي:      
            </h5>
            <table class="stc_table">
              <tbody>
                <tr>
                  <td>
                    <p><strong>م</strong></p>
                  </td>
                  <td>
                    <p><strong>الاسم</strong></p>
                  </td>
                  <td>
                    <p><strong>الحضور</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>1</strong></p>
                  </td>
                  <td>
                    <p><span">صاحب &rlm;السمو الملكي الأمير/ محمد بن خالد العبد الله الفيصل&nbsp;</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>2</strong></p>
                  </td>
                  <td>
                    <p><span">الدكتور/ خالد بن حسين بياري</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>3</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ محمد بن طلال النحاس</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>4</strong></p>
                  </td>
                  <td>
                    <p><span">&rlm;الأستاذ/ راشد بن إبراهيم شريف</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>5</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ سانجـــاي كابـور</span></p>
                  </td>
                  <td>
                    <p><strong>&times;</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>6</strong></p>
                  </td>
                  <td>
                    <p><span">&rlm;الأستاذ/ روي تشـســنـــــــــــات</span></p>
                  </td>
                  <td>
                    <p><strong>&times;</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>7</strong></p>
                  </td>
                  <td>
                    <p><span">&rlm;الدكتور/ إبراهيم بن عبدالرحمن القاضي</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>8</strong></p>
                  </td>
                  <td>
                    <p><span">&rlm;الأستاذ/ أسامة بن ياسين الخياري</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>9</strong></p>
                  </td>
                  <td>
                    <p><span">&rlm;الأستاذ/ أحمد بن محمد العمران</span></p>
                  </td>
                  <td>
                    <p><span">✔</span></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="inner-wrapper"></div>
            <p class="content_para margint50" style="margin-right: 50px;">
              يعزى عدم حضور الأستاذ/ سانجـــاي كابـور، والأستاذ/ روي تشـســنـــــــــــات، لارتباطهما مسبقاً.
               <br>
               <br>
              يمكن الاطلاع على محاضر الاجتماعات في موقع stc الإلكتروني www.stc.com.sa
            </p>


          <div class="sp_wrap cwrapper">
              <div class="screentop_para">
                <h1>
                  <span class="h1 colr_white bk_pink" style="padding: 5px 15px 5px 150px;"> ‫
                    ‫التقييم السنوي
                  </span> 
                </h1>
                <h1>
                  <span class="h1 colr_purple"> 
                  ‫ لمجلس الإدارة
                  </span>
                </h1>
              </div>
              <div class="content-wrapper">
                <div class="xright" style="margin-right: 50px;">
                  <div class="col9">
                    <h5 class="h5 colr_purple">
                  ‫‫سياسة الشركة في توزيع الأرباح         
                  </h5>
                  <p class="content_para">
                    ‫‫تنص المادة (45) من النظام الأساس للشركة على توزيع أرباح الشركة الصافية السنوية على الوجه الآتي: 
                    <br><br>
                    ‫‫يجنب (10%) من صافي الأرباح لتكوين الاحتياطي النظامي للشركة، ويجوز أن تقرر الجمعية العامة العادية وقف هذا التجنيب متى بلغ الاحتياطي المذكور (30%) من رأس المال المدفوع .
                    <br><br>
                    ‫ للجمعية العامة العادية، بناءً على اقتراح مجلس الإدارة، أن تجنب نسبة مئوية من الأرباح السنوية لتكوين احتياطي اتفاقي يخصص لغرض أو أغراض تقررها الجمعية العامة.
                    <br><br>
                    للجمعية العامة العادية أن تقرر تكوين احتياطيات أخرى، وذلك بالقدر الذي يحقق مصلحة الشركة أو يكفل توزيع أرباح ثابتة قدر الإمكان على المساهمين، وللجمعية المذكورة كذلك أن تقتطع من صافي الأرباح مبالغ لإنشاء مؤسسات اجتماعية لعاملي الشركة أو لمعاونة ما يكون قائماً من هذه المؤسسات. 
                    <br><br>
                    ‫‫يوزع من الباقي بعد ذلك على المساهمين نسبة تمثل (5%) من  رأس مال  الشركة المدفوع.
                    <br><br>
                    ‫‫مع مراعاة الأحكام المقررة في المادة (21) من النظام الأساس لشركة الاتصالات السعودية، والمادة (76) من نظام الشركات، للجمعية العامة تخصيص بعد ما تقدم مكافأة أعضاء مجلس الإدارة، على أن يكون استحقاق هذه المكافأة متناسباً مع عدد الجلسات التي يحضرها العضو.
                    <br><br>
                    ‫‫للجمعية العامة العادية أن تقرر -بناءً على اقتراح مجلس الإدارة- توزيع الباقي بعد ما تقدم (إن وجد) على المساهمين كحصة إضافية من الأرباح. 
                    <br><br>
                    ‫كما يجوز للشركة توزيع أرباح مرحلية على مساهميها بشكل نصف سنوي أو ربع سنوي وفقاً للضوابط الصادرة عن الجهة المختصة، وذلك بناءً على تفويض صادر من قبل الجمعية العامة العادية لمجلس الإدارة بتوزيع أرباح مرحلية.
                    <br><br>
                    ‫كما تنص المادة (46) من النظام الأساس لشركة الاتصالات السعودية، على استحقاق المساهم حصته في الأرباح "وفقاً لقرار الجمعية العامة الصادر في هذا الشأن، ويبين القرار تاريخ الاستحقاق وتاريخ التوزيع وتكون أحقية الأرباح لمالكي الأسهم المسجلين في سجلات المساهمين في نهاية اليوم المحدد للاستحقاق، وتدفع الأرباح المقرر توزيعها على المساهمين في المكان والمواعيد والآليات التي يحددها مجلس الإدارة وفقاً للتعليمات التي تصدرها الجهات المختصة". 
                     <br><br>
                     وقد أقرّ مجلس الإدارة في اجتماعه المنعقد بتاريخ 9/4/1440هـ (الموافق 16/12/2018م) سياسة توزيع الأرباح، واعتمدت السياسة في اجتماع الجمعية العامة بتاريخ 19/8/1440هـ (الموافق 24/4/2019م)، وهي سياسة توزيعات تقوم على أساس الحفاظ على حد أدنى من التوزيعات للسهم الواحد على أساس ربع سنوي، وذلك بتوزيع ريال سعودي واحد عن كل ربع سنة، لمدة ثلاث سنوات قادمة ابتداءً من الربع الرابع من عام 2018م، وسوف تنظر الشركة بدفع توزيعات إضافية، بحيث تخضع هذه التوزيعات الإضافية لتوصية مجلس الإدارة بعد تقييم الوضع المالي للشركة والتوقعات المستقبلية والمتطلبات الرأسمالية للشركة، وقد تتفاوت هذه التوزيعات الإضافية من ربع سنة إلى آخر بناءً على أداء الشركة. علماً أن سياسة توزيعات الأرباح قابلة للتغيير بناءً على التالي:
                     <br><br>
                     أي تغييرات جوهرية في استراتيجية وأعمال الشركة (بما في ذلك البيئة التجارية التي تعمل بها الشركة).
                     <br><br>
                     القوانين، والأنظمة، والتشريعات، والضوابط المنظمة للقطاع والتي تخضع لها الشركة.
                     <br><br>
                     أي التزامات أو تعهدات لجهات مصرفية أو تمويلية أو مقابلة متطلبات وكالات التصنيف الائتماني، التي قد تكون ملزمة على الشركة من وقت لآخر. 
                     <br><br>
                  </p>
                  </div>
                  
                </div>
                <!-- <div class="right marginr50">
                  <div class="box_center_content bk_purple" style="padding:60px;">
                    <p class="content_para colr_white">
                      ‫‫‫‪‫‪أقر مجلس الإدارة في اجتماعه بتاريخ 4/7/1439هـ (الموافق 21/3/2018م) سياسة تقييم أداء مجلس الإدارة ولجانه، وتهدف هذه السياسة إلى تحديد قواعد العمل والضوابط المعنية بتقييم أداء المجلس ولجانه، لغرض المتابعة وتطوير الأداء، والوفاء بالمتطلبات النظامية، وتطبيق أفضل الممارسات في مجال الحوكمة، وتعزيز فاعلية المجلس. وقد تعاقدت stc في شهر سبتمبر 2019م مع استشاري متخصص لإجراء دراسة وتقييم لفاعلية وأداء المجلس عام 2019م، وستعرض نتائج التقييم النهائية على المجلس بتاريخ 17/3/2020م، حيث شارك أعضاء المجلس في عملية التقييم من خلال التعاون الكامل مع الاستشاري المستقل والإدلاء بآرائهم في عدد من المجالات من بينها: هيكل ودور مجلس الإدارة ولجانه، والتفاعل بين أعضاء المجلس كفريق واحد، والمجلس والإدارة التنفيذية، والحوكمة والتحديات والمخاطر وكيفية إدارتها.
                    </p>
                  </div>
                </div> -->
              </div>
          </div>
          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
              <div class="right marginr50 noheight" style="position: relative; width: 50%;">
                 <b class="content_para">
              ‫‫‫وصف لأي مصلحة وأوراق تعاقدية وحقوق اكتتاب تعود لأعضاء مجلس الإدارة وأقربائهم في أسهم أو أدوات دين للشركة (الدورة السابعة)
                </b>
              </div>
            </div>
          </div>

          <!-- <div class="tabular_data2 margint50">
             <div class="c_row first bk_purple">
                <div>‫‫م‬‬</div>
                <div>
                ‫‫‫العضو‬ ‫اسم‬
                </div>
                <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫بداية‬</div>
                   <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫ا‫الدين‬ ‫أدوات‬</span>
                   </div>
                </div>
                 <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫نهاية‬</div>
                     <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫‫الدين‬ ‫أدوات‬</span>
                   </div>
                 </div>
                 <div>‫
                  ‫التغيير‬ ‫صافي‬
                </div>
                 <div>
                  ‫‫التغيير‬ ‫نسبة‬
                 </div>
               
             </div>
              <div class="c_row first table_white">
               <div>1</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>2</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>3</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>4</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
          </div> -->
          <div class="ctable_wrapper">
            <table class="stc_table">
              <tbody>
                <tr>
                  <td rowspan="2">
                    <p><strong>م</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>اسم العضو</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>بداية العام 2019</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>نهاية العام 2019</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>صافي التغيير</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>نسبة التغيير</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>1</strong></p>
                  </td>
                  <td>
                    <p><span">صاحب السمو الملكي الأمير/ محمد بن خالد العبدالله الفيصل</span></p>
                  </td>
                  <td>
                    <p><span">14,823</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">1,000</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">)13,823)</span></p>
                  </td>
                  <td>
                    <p><span">(%93.25)</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>2</strong></p>
                  </td>
                  <td>
                    <p><span">الدكتور/ خالد بن حسين بياري</span></p>
                  </td>
                  <td>
                    <p><span">2,000</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">2,000</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>3</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ محمد بن طلال النحاس</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>4</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ راشد بن ابراهيم شريف</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>5</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ سانجاي كابور</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>6</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ روي تشـســنـــــــــــات</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>7</strong></p>
                  </td>
                  <td>
                    <p><span">الدكتور/ إبراهيم بن عبدالرحمن القاضي</span></p>
                  </td>
                  <td>
                    <p><span">2,666</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">2,666</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>8</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ أسامة بن ياسين الخياري</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>9</strong></p>
                  </td>
                  <td>
                    <p><span">الأستاذ/ أحمد بن محمد العمران</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0</span></p>
                  </td>
                  <td>
                    <p><span">0 %&nbsp;</span></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>


          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
              <div class="right marginr50 noheight" style="position: relative; width: 50%;">
                 <b class="content_para">
              ‫‫‫وصف لأي مصلحة وأوراق تعاقدية وحقوق اكتتاب تعود لأعضاء مجلس الإدارة وأقربائهم في أسهم أو أدوات دين الشركات التابعة (الدورة السابعة)
                </b>
              </div>
            </div>
          </div>

          <!-- <div class="tabular_data2 margint50">
             <div class="c_row first bk_purple">
                <div>‫‫م‬‬</div>
                <div>
                ‫‫‫العضو‬ ‫اسم‬
                </div>
                <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫بداية‬</div>
                   <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫ا‫الدين‬ ‫أدوات‬</span>
                   </div>
                </div>
                 <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫نهاية‬</div>
                     <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫‫الدين‬ ‫أدوات‬</span>
                   </div>
                 </div>
                 <div>‫
                  ‫التغيير‬ ‫صافي‬
                </div>
                 <div>
                  ‫‫التغيير‬ ‫نسبة‬
                 </div>
               
             </div>
              <div class="c_row first table_white">
               <div>1</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>2</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>3</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>4</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
          </div> -->

          <div class="ctable_wrapper">
            <table class="stc_table">
              <tbody>
                <tr>
                  <td rowspan="2">
                    <p><strong>م</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>اسم العضو</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>اسم الشركة التابعة</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>بداية العام 2019</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>نهاية العام 2019</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>صافي التغيير</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>نسبة التغيير</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>1</strong></p>
                  </td>
                  <td>
                    <p><span>صاحب السمو الملكي الأمير/ محمد بن خالد العبدالله الفيصل</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>2</strong></p>
                  </td>
                  <td>
                    <p><span>الدكتور/ خالد بن حسين بياري</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>3</strong></p>
                  </td>
                  <td>
                    <p><span>الأستاذ/ محمد بن طلال النحاس</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>4</strong></p>
                  </td>
                  <td>
                    <p><span>الأستاذ/ راشد بن ابراهيم شريف</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>5</strong></p>
                  </td>
                  <td>
                    <p><span>الأستاذ/ سانجاي كابور</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>6</strong></p>
                  </td>
                  <td>
                    <p><span>الأستاذ/ روي تشـســنـــــــــــات</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>7</strong></p>
                  </td>
                  <td>
                    <p><span>الدكتور/ إبراهيم بن عبدالرحمن القاضي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>8</strong></p>
                  </td>
                  <td>
                    <p><span>الأستاذ/ أسامة بن ياسين الخياري</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>9</strong></p>
                  </td>
                  <td>
                    <p><span>الأستاذ/ أحمد بن محمد العمران</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
              <div class="right marginr50 noheight" style="position: relative; width: 50%;">
                 <b class="content_para">
              ‫‫‫وصف لأي مصلحة وأوراق تعاقدية وحقوق اكتتاب تعود لكبار التنفيذيين وأقربائهم في أسهم أو أدوات دين للشركة
                </b>
              </div>
            </div>
          </div>

          <!-- <div class="tabular_data2 margint50">
             <div class="c_row first bk_purple">
                <div>‫‫م‬‬</div>
                <div>
                ‫‫‫العضو‬ ‫اسم‬
                </div>
                <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫بداية‬</div>
                   <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫ا‫الدين‬ ‫أدوات‬</span>
                   </div>
                </div>
                 <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫نهاية‬</div>
                     <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫‫الدين‬ ‫أدوات‬</span>
                   </div>
                 </div>
                 <div>‫
                  ‫التغيير‬ ‫صافي‬
                </div>
                 <div>
                  ‫‫التغيير‬ ‫نسبة‬
                 </div>
               
             </div>
              <div class="c_row first table_white">
               <div>1</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>2</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>3</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>4</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
          </div> -->

          <div class="ctable_wrapper">
            <table class="stc_table">
              <tbody>
                <tr>
                  <td rowspan="2">
                    <p><strong>م</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>اسم العضو</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>بداية العام 2019م</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>نهاية العام 2019م</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>صافي التغيير</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>نسبة التغيير</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>1</span></p>
                  </td>
                  <td>
                    <p><span>م. ناصر بن سليمان الناصر</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>2</span></p>
                  </td>
                  <td>
                    <p><span>أ. أمين بن فهد الشدي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>3</span></p>
                  </td>
                  <td>
                    <p><span>م. عماد بن عودة العودة</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>4</span></p>
                  </td>
                  <td>
                    <p><span>&nbsp;جيرمي سيل</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>5</span></p>
                  </td>
                  <td>
                    <p><span>م. هيثم بن محمد الفرج</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>6</span></p>
                  </td>
                  <td>
                    <p><span>أ. عبدالله بن محسن العويني</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>7</span></p>
                  </td>
                  <td>
                    <p><span>أ. عبدالعزيز بن عبدالله القطعي</span></p>
                  </td>
                  <td>
                    <p><span>4,500</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>4,500</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>8</span></p>
                  </td>
                  <td>
                    <p><span>أ. رياض بن سعيد معوض</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>9</span></p>
                  </td>
                  <td>
                    <p><span>أ. رياض بن حمدان العنزي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>10</span></p>
                  </td>
                  <td>
                    <p><span>م. أحمد بن مسفر الغامدي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>11</span></p>
                  </td>
                  <td>
                    <p><span>م. محمد بن عبدالله العبادي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>12</span></p>
                  </td>
                  <td>
                    <p><span>أ. سلطان بن حسن بن سعيد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>13</span></p>
                  </td>
                  <td>
                    <p><span>د. خالد بن منصور البراك</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>14</span></p>
                  </td>
                  <td>
                    <p><span>أ. ماركوس جولدير</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>15</span></p>
                  </td>
                  <td>
                    <p><span>أ. وجناند ارنست فان تيل</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>16</span></p>
                  </td>
                  <td>
                    <p><span>أ. الان فرانسيس ويلان</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>17</span></p>
                  </td>
                  <td>
                    <p><span>أ. عبد الله بن صايل العنزي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>18</span></p>
                  </td>
                  <td>
                    <p><span>ديمتريوس لولياس</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>19</span></p>
                  </td>
                  <td>
                    <p><span>رأفت باري مالك</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>20</span></p>
                  </td>
                  <td>
                    <p><span>علي عبدالله حميد الفقيه الحربي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>21</span></p>
                  </td>
                  <td>
                    <p><span>بدر عبدالله سليمان اللهيب</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>22</span></p>
                  </td>
                  <td>
                    <p><span>ياسر زابن العتيبي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>23</span></p>
                  </td>
                  <td>
                    <p><span>خالد إبراهيم عبدالرحمن الضراب</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>24</span></p>
                  </td>
                  <td>
                    <p><span>عليان محمد حمد بن وتيد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>25</span></p>
                  </td>
                  <td>
                    <p><span>عثمان دهش عثمان الدهش</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>26</span></p>
                  </td>
                  <td>
                    <p><span>عبدالعزيز محمد عبدالرحمن الحيدر</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>27</span></p>
                  </td>
                  <td>
                    <p><span>ياسر نجيب عبدالعزيز السويلم</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>28</span></p>
                  </td>
                  <td>
                    <p><span>بندر مسلم عاتق اللحياني</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>29</span></p>
                  </td>
                  <td>
                    <p><span>منيف نايف بندر بن درويش</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>30</span></p>
                  </td>
                  <td>
                    <p><span>معضد فيصل معضد العجمي</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>31</span></p>
                  </td>
                  <td>
                    <p><span>يزيد عبدالعزيز عبدالرحمن الفارس</span></p>
                  </td>
                  <td>
                    <p><span>1,200</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>1,200</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>32</span></p>
                  </td>
                  <td>
                    <p><span>امير عبدالعزيز حمد الجبرين</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>33</span></p>
                  </td>
                  <td>
                    <p><span>عبدالله عبدالرحمن عبدالله الكنهل</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>34</span></p>
                  </td>
                  <td>
                    <p><span>فيصل عبدالعزيز آدم البكري</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>


          <div class="sp_wrap">
            <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
              <div class="right marginr50 noheight" style="position: relative; width: 50%;">
                 <b class="content_para">
              ‫‫‫وصف لأي مصلحة وأوراق تعاقدية وحقوق اكتتاب تعود لكبار التنفيذيين وأقربائهم في أسهم أو أدوات دين الشركات التابعة
                </b>
              </div>
            </div>
          </div>

          <!-- <div class="tabular_data2 margint50">
             <div class="c_row first bk_purple">
                <div>‫‫م‬‬</div>
                <div>
                ‫‫‫العضو‬ ‫اسم‬
                </div>
                <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫بداية‬</div>
                   <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫ا‫الدين‬ ‫أدوات‬</span>
                   </div>
                </div>
                 <div class="c_row last">
                   <div class="c_row f-row" style="padding:10px 20px;">‫‫‪2019‬‬ ‫العام‬ ‫نهاية‬</div>
                     <div class="c_row f-row">
                     <span>‫‫سهم‬ ‫ا‬ ‫عدد‬</span>
                     <span>‫‫الدين‬ ‫أدوات‬</span>
                   </div>
                 </div>
                 <div>‫
                  ‫التغيير‬ ‫صافي‬
                </div>
                 <div>
                  ‫‫التغيير‬ ‫نسبة‬
                 </div>
               
             </div>
              <div class="c_row first table_white">
               <div>1</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>2</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>3</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
              <div class="c_row first table_white">
               <div>4</div>
               <div></div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div class="c_row last">
                 <div class="c_row f-row">
                   <span></span>
                   <span></span>
                 </div>
               </div>
               <div>
               </div>
               <div></div>
              </div>
          </div> -->

          <div class="ctable_wrapper">
            <table class="stc_table">
              <tbody>
                <tr>
                  <td rowspan="2">
                    <p><strong>م</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>اسم العضو</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>اسم الشركة التابعة</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>بداية العام 2019م</strong></p>
                  </td>
                  <td colspan="2">
                    <p><strong>نهاية العام 2019م</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>صافي التغيير</strong></p>
                  </td>
                  <td rowspan="2">
                    <p><strong>نسبة التغيير</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                  <td>
                    <p><strong>عدد الأسهم</strong></p>
                  </td>
                  <td>
                    <p><strong>أدوات الدين</strong></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>1</span></p>
                  </td>
                  <td>
                    <p><span>م. ناصر بن سليمان الناصر</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>2</span></p>
                  </td>
                  <td>
                    <p><span>أ. أمين بن فهد الشدي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>3</span></p>
                  </td>
                  <td>
                    <p><span>م. عماد بن عودة العودة</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>4</span></p>
                  </td>
                  <td>
                    <p><span>&nbsp;جيرمي سيل</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>5</span></p>
                  </td>
                  <td>
                    <p><span>م. هيثم بن محمد الفرج</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>6</span></p>
                  </td>
                  <td>
                    <p><span>أ. عبدالله بن محسن العويني</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>7</span></p>
                  </td>
                  <td>
                    <p><span>أ. عبدالعزيز بن عبدالله القطعي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>8</span></p>
                  </td>
                  <td>
                    <p><span>أ. رياض بن سعيد معوض</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>9</span></p>
                  </td>
                  <td>
                    <p><span>أ. رياض بن حمدان العنزي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>10</span></p>
                  </td>
                  <td>
                    <p><span>م. أحمد بن مسفر الغامدي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>11</span></p>
                  </td>
                  <td>
                    <p><span>م. محمد بن عبدالله العبادي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>12</span></p>
                  </td>
                  <td>
                    <p><span>أ. سلطان بن حسن بن سعيد</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>13</span></p>
                  </td>
                  <td>
                    <p><span>د. خالد بن منصور البراك</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>14</span></p>
                  </td>
                  <td>
                    <p><span>أ. ماركوس جولدير</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>15</span></p>
                  </td>
                  <td>
                    <p><span>أ. وجناند ارنست فان تيل</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>16</span></p>
                  </td>
                  <td>
                    <p><span>أ. الان فرانسيس ويلان</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>17</span></p>
                  </td>
                  <td>
                    <p><span>أ. عبد الله بن صايل العنزي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>18</span></p>
                  </td>
                  <td>
                    <p><span>ديمتريوس لولياس</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>19</span></p>
                  </td>
                  <td>
                    <p><span>رأفت باري مالك</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>20</span></p>
                  </td>
                  <td>
                    <p><span>علي عبدالله حميد الفقيه الحربي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>21</span></p>
                  </td>
                  <td>
                    <p><span>بدر عبدالله سليمان اللهيب</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>22</span></p>
                  </td>
                  <td>
                    <p><span>ياسر زابن العتيبي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>23</span></p>
                  </td>
                  <td>
                    <p><span>خالد إبراهيم عبدالرحمن الضراب</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>24</span></p>
                  </td>
                  <td>
                    <p><span>عليان محمد حمد بن وتيد</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>25</span></p>
                  </td>
                  <td>
                    <p><span>عثمان دهش عثمان الدهش</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>26</span></p>
                  </td>
                  <td>
                    <p><span>عبدالعزيز محمد عبدالرحمن الحيدر</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>27</span></p>
                  </td>
                  <td>
                    <p><span>ياسر نجيب عبدالعزيز السويلم</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>28</span></p>
                  </td>
                  <td>
                    <p><span>بندر مسلم عاتق اللحياني</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>29</span></p>
                  </td>
                  <td>
                    <p><span>منيف نايف بندر بن درويش</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>30</span></p>
                  </td>
                  <td>
                    <p><span>معضد فيصل معضد العجمي</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>31</span></p>
                  </td>
                  <td>
                    <p><span>يزيد عبدالعزيز عبدالرحمن الفارس</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>32</span></p>
                  </td>
                  <td>
                    <p><span>امير عبدالعزيز حمد الجبرين</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>33</span></p>
                  </td>
                  <td>
                    <p><span>عبدالله عبدالرحمن عبدالله الكنهل</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>34</span></p>
                  </td>
                  <td>
                    <p><span>فيصل عبدالعزيز آدم البكري</span></p>
                  </td>
                  <td>
                    <p><span>لا يوجد</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0</span></p>
                  </td>
                  <td>
                    <p><span>0%</span></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="sp_wrap cwrapper">
          <div class="screentop_para">
              <h1>
                <span class="h1 colr_purple"> ‫
                 ‫حوكمة 
                </span> 
              </h1>
              <h1>
                <span class="h1  colr_white bk_purple"  style="padding: 5px 15px 5px 150px;"> 
               ‫الشركة
                </span>
            </h1>
            </div>
          <div class="content-wrapper">
            <div class="left">
             <div class="img-wrap">
               <img src="img/guy_tab1.jpg">
             </div>
            </div>
            <div class="right marginr50">
             <p class="content_para">
              ‫‫حرص مجلس إدارة stc على تأسيس نظام حوكمة فاعل واعتباره جزء لا يتجزأ من نظام الشركة الإداري والمالي، حيث يتولى نظام الحوكمة تنظيم الأعمال الداخلية من خلال إيضاح العلاقة بين مجلس الإدارة وجمعية المساهمين من جهة، ومجلس الإدارة والإدارة التنفيذية من جهة أخرى، كما يتولى نظام الحوكمة في stc تنظيم الأعمال الخارجية من خلال إدارة علاقاتها مع القطاعات الحكومية والجهات التشريعية والمورّدين والمقاولين بغرض تحقيق كفاءة وفاعلية عالية تكفل تحقيق أهداف stc الاستراتيجية. كما تحرص stc على شمولية التنظيمات وقواعد العمل المتعلقة بالتوجيه والمراقبة والشفافية لتكون متوافقة مع ما ورد في نظام الشركات الصادر من مقام وزارة التجارة والاستثمار ولائحة حوكمة الشركات الصادرة من مجلس إدارة هيئة السوق المالية، والأنظمة الأخرى ذات العلاقة، بالإضافة إلى رفع مستوى حوكمة الأعمال في stc من خلال الاستفادة من أفضل الممارسات الإقليمية والعالمية.
              <br>
              <br>
              ‫‫لقد مكن نظام الحوكمة في stc من تحقيق الاستدامة المستهدفة والتي تعتبر ركيزة هامة من ركائز استراتيجية مجموعة stc، فأعمال الشركة ونشاطاتها تستند على وثائق معتمدة من قبل الجهات المعنية، ومن ذلك على سبيل المثال لا الحصر النظام الأساس لشركة stc والمعتمد من قبل وزارة التجارة والاستثمار بعد عرضه على الجمعية العامة، وسياسة توزيع الأرباح المعتمدة من الجمعية العامة، ولوائح عمل مجلس الإدارة واللجان المنبثقة عنه كلائحة عمل لجنة المراجعة المعتمدة من قبل الجمعية العامة، ولائحة حوكمة stc المعتمدة من قبل مجلس الإدارة. كما أن توثيق مصفوفة تفويض الصلاحيات الاستراتيجية والمالية يعد مطلباً أساسياً من متطلبات ضوابط الرقابة الداخلية في stc حيث أنها تعمل على تحديد المسؤوليات والصلاحيات الاستراتيجية والمالية لشاغلي الوظائف الادارية المفوضين باعتماد القرارات والمعاملات في stc، والتي من شأنها أن تعزز من ضبط وحوكمة آليات اتخاذ القرارات الرسمية، وتمنع مخاطر الغش والاحتيال.
              <br>
              <br>
              ولأهمية وجود استراتيجية خاصة بالحوكمة مرتبطة وبشكل واضح مع استراتيجية stc، حرصت الإدارة التنفيذية وبدعم من لجنة الترشيحات والمكافآت في مجلس الإدارة على تطوير واعتماد استراتيجية الحوكمة في بداية العام 2019م، والتي تضمنت محاور رئيسة تشكل التوجه الاستراتيجي للشركة في هذا الشأن. كما تضمنت الاستراتيجية المعتمدة مجموعة من المبادرات الاستراتيجية المستهدفة بالتطوير، حيث أكمل الفريق المختص بأعمال الحوكمة في الشركة إنجاز بعضٍ منها على مستوى الجمعية العامة كاعتماد سياسة توزيع الأرباح من الجمعية العامة، واعتماد سياسة تعارض المصالح وسياسة السلوك المهني من مجلس الإدارة. كما عمل الفريق المختص بأعمال الحوكمة على تطوير أعمال على مستوى الإدارة التنفيذية ومنها تطوير إطار عمل الحوكمة في stc، وإطار عمل اللجان الإدارية.
              <br>
              <br>
              وللحوكمة علاقة وطيدة بما يستجد من متغيرات على صعيد الأنظمة والتشريعات الصادرة من قبل القطاعات الحكومية وشبه الحكومية، مما يعني ضرورة عمل تقييم مستمر لوثائق الحوكمة في stc وتحديثها وفقاً لما يستجد من تنظيمات وتشريعات. كما تبنت الإدارة التنفيذية إطلاق مبادرة سنوية تهدف إلى عمل تقييم سنوي داخلي لجميع الوثائق والأعمال المعنية بالحوكمة بغرض البحث عن فرص التحسين والعمل على تطويرها. لقد كان لهذه المبادرة الأثر الإيجابي على أعمال الشركة وما حققتها من إنجازات، حيث استطاعت بعد توفيق الله سبحانه من تحقيق جائزة التميز في الحوكمة المقدمة من مركز حوكمة الشركات والذي تشرف عليه هيئة السوق المالية والهيئة العامة للاستثمار وبإدارة جامعة الفيصل، وجاء تكريم stc خلال المؤتمر العالمي الأول لحوكمة الشركات المنعقد في مدينة الرياض خلال العام 2019م.
              <br>
              <br>
              وقد تم تطبيق جميع أحكام لائحة حوكمة الشركات الصادرة من هيئة السوق المالية باستثناء المادة الخمسون (الفقرة رابعاً)، التي تنص على ألا يقل عدد أعضاء اللجان عن ثلاثة ولايزيد عن خمسة، في حين تتكون اللجنة التنفيذية من أربعة أعضاء من أعضاء مجلس الإدارة، وعضوين خارجيين، أحدهم الرئيس التنفيذي للشركة، وذلك بسبب حجم الأعمال والاختصاصات المناطة باللجنة.           
             </p>
             <br><br><br>
             
            </div>
          </div>
          <div class="content-wrapper inner-wrapper c-row-reverse sp_row">
                  <div class="left" style="position: relative;">
                  <div class="bar-wrap">
                     <div class="element_bars_hr" style="width: 100%;position: absolute;right: 0;height: 100%;">
                          <div class="leftbar bk_purple" style="width: 90%"></div>
                          <div class="rightbar bk_pink" style="width: 10%"></div>
                    </div>
                  </div>
                  </div>
                  <div class="right">
                    <p class="content_para">
                      الرقابة الداخلية
                      <br><br>
                      يقر مجلس إدارة الشركة بأن سجلات الحسابات أعدت بالشكل الصحيح، وأن نظام وإجراءات الرقابة الداخلية أعد على أسس سليمة وكفاءة عالية، دون وجود ملحوظات جوهرية قد تؤثر في قدرة الشركة على مواصلة نشاطها. وتشرف لجنة المراجعة المنبثقة عن مجلس الإدارة على أعمال إدارة الالتزام وإدارة المخاطر والمراجعة الداخلية التي تفحص بشكل دوري مدى كفاية وفاعلية نظام وإجراءات الرقابة الداخلية بما يمكن من توفير تقويم مستمر لنظام الرقابة الداخلية ومدى فاعليته. ويأتي ذلك ضمن أهداف مجلس الإدارة في الحصول على اقتناع معقول عن مدى سلامة تصميم وفاعلية أداء نظام الرقابة الداخلية في الشركة، حيث عقدت لجنة المراجعة في هذا السبيل وخلال العام المالي 2019م سبعة اجتماعات ناقشت خلالها عدداً من الموضوعات ذات الصلة بأعمال اللجنة ومنها على سبيل المثال مراجعة القوائم المالية والاستثمارات ومراجعة وحدات الأعمال في الشركة وكذلك الشؤون الاستراتيجية والتنظيمية والموارد البشرية والمشتريات، إضافة إلى مراجعة أنظمة تقنية المعلومات، وذلك بحضور المسؤولين في الإدارة التنفيذية والمراجعة الداخلية، إلى غير ذلك من المسائل المتعلقة بسير العمل في الشركة من جميع الجوانب.
                  </div>
          </div>
          <div class="sp_wrap cwrapper">
            <div class="screentop_para">
              <h1>
                <span class="h1 colr_white bk_purple" style="padding: 5px 15px 5px 150px;"> ‫
                  ‫المراجعة
                </span> 
              </h1>
              <h1>
                <span class="h1 colr_purple"> 
                ‫الداخلية
                </span>
            </h1>
            </div>
            <div class="content-wrapper sp2_row">
              <div class="left pink_border ">
              </div>
              <div class="right bk_purple nopadding marginr50" style="height: auto !important; padding: 50px 0 !important;">
                <div class="box_center_content">
                  <p class="content_para colr_white" style="text-align: right;">
                    ‫‫تقدم المراجعة الداخلية في الشركة خدمات تأكيدية واستشارية باستقلالية وموضوعية بغرض إضافة قيمة وتحسين العمليات وتحقيق أهداف الشركة العليا. وتساعد المراجعة الداخلية الشركة st في تحقيق أهدافها من خلال تبني مدخل منتظم لتقويم وتحسين فاعلية إدارة المخاطر والرقابة الداخلية. وقد نفّذت المراجعة الداخلية العديد من عمليات المراجعة الدورية والخاصة وفقاً لخطة المراجعة السنوية المعتمدة من قبل لجنة المراجعة بهدف إعطاء التأكيدات اللازمة بشأن فاعلية وكفاءة الرقابة الداخلية وإدارة المخاطر في الشركة ، مع التركيز على الأنشطة والوظائف ذات المخاطر العالية. وشملت خطة المراجعة السنوية على سبيل المثال مراجعة السياسات والإجراءات المتعلقة بالمشتريات والشؤون الاستراتيجية والموارد البشرية وتقنية المعلومات ووحدات الأعمال إضافة إلى القطاع المالي، كما تقدم المراجعة الداخلية خدمات استشارية بغرض الاسهام مع الإدارة التنفيذية في تحسين كفاءة وفاعلية عمليات الشركة المختلفة، وخفض التكاليف والحد من فقد الإيرادات، إضافة إلى الإسهام في مراجعة القوائم المالية الأولية والسنوية وتنسيق أعمال الجهات الرقابية الخارجية، علماً بأن عمليات المراجعة المشار إليها لم تظهر وجود ملحوظات جوهرية تؤثر  في قدرة الشركة في مواصلة تنفيذ أعمالها. كما استعرضت لجنة المراجعة نتائج التقييم الخارجي المستقل لمستوى نضج المراجعة الداخلية الذي خلص إلى التزام المراجعة الداخلية بالمعايير المنظمة لعملها، واتباعها أفضل الممارسات المهنية والمعايير الصادرة بهذا الشأن.     
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div class="content-wrapper ">
              <div class="left">
               <div class="screentop_para nomargin">
                  <h1>
                  <span class="h1 colr_purple"> ‫
                  </span> 
                  </h1>
                  <h1>
                  <span class="h1 colr_white bk_purple"  style="padding: 5px 15px 5px 150px;"> 
                  </span>
                  </h1>
                </div>
                 <p class="content_para margint50 col8">
                 </p>
              </div>
              <div class="right marginr50">
                <div class="img-wrap">
                 <img src="img/guy_tab1.jpg">
                </div>
              </div>
          </div>

          <div class="sp_wrap cwrapper">
            <div class="screentop_para">
              <h1>
                <span class="h1 colr_purple"> ‫
                  سجل
                </span> 
              </h1>
              <h1>
                <span class="h1 colr_white bk_purple" style="padding: 5px 15px 5px 150px;"> 
                ‫المساهمين
                </span>
            </h1>
            </div>
            <div class="content-wrapper sp2_row">
              <div class="left">
                <div class="img-wrap">
                  <img src="img/guy_tab1.jpg">
                </div>
              </div>
              <div class="right pink_border nopadding">
                <div class="box_center_content">
                  <p class="content_para" style="text-align: right;">
                  ‫تم الطلب (13) مرة لسجل المساهمين من شركة مركز إيداع الأوراق المالية خلال عام 2019م وذلك للأغراض التالية :
                  <br><br><br>
                  ‫تحديث سجل المساهمين شهرياً .
                  <br><br><br>
                  ‫توزيع الأرباح الربع سنوية .
                  <br><br><br>
                  ‫عقد الجمعية العمومية .
                  </p>
                </div>
              </div>
            </div>
          </div>
          <!-- <div class="tabular_data margint50">
                <div class="c_row first bk_purple nomargin">
                   <div>م</div>
                    <div>‫المساهمين‬ ‫سجل‬ ‫طلب‬ ‫تاريخ‬</div>
                    <div>‫‫المساهمين‬ ‫سجل‬ ‫طلب‬ ‫تاريخ‬</div>
                </div>
                <div class="tabular_data_inner">
                 
                  <div class="c_row">
                    <div>1</div>
                    <div></div>
                    <div></div>
                  </div>
                  <div class="c_row">
                    <div>2</div>
                    <div></div>
                    <div></div>
                  </div>
                  <div class="c_row">
                    <div>3</div>
                    <div></div>
                    <div></div>
                  </div>
                </div>
          </div> -->

          <div class="ctable_wrapper">
            <table class="stc_table">
              <tbody>
                <tr>
                  <td>
                    <p><span>م</span></p>
                  </td>
                  <td>
                    <p><span>تاريخ طلب سجل المساهمين</span></p>
                  </td>
                  <td>
                    <p><span>مبررات الطلب</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>1</span></p>
                  </td>
                  <td>
                    <p><span>31/1/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>2</span></p>
                  </td>
                  <td>
                    <p><span>28/2/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>3</span></p>
                  </td>
                  <td>
                    <p><span>31/3/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>4</span></p>
                  </td>
                  <td>
                    <p><span>24/4/2019م</span></p>
                  </td>
                  <td>
                    <p><span>الجمعية العامة</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>5</span></p>
                  </td>
                  <td>
                    <p><span>24/4/2019م</span></p>
                  </td>
                  <td>
                    <p><span>توزيع الأرباح ربع السنوية الربع الرابع لعام 2018</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>6</span></p>
                  </td>
                  <td>
                    <p><span>5/5/2019م</span></p>
                  </td>
                  <td>
                    <p><span>توزيع الأرباح ربع السنوية الربع الأول لعام 2019</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>7</span></p>
                  </td>
                  <td>
                    <p><span>30/6/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>8</span></p>
                  </td>
                  <td>
                    <p><span>29/7/2019م</span></p>
                  </td>
                  <td>
                    <p><span>توزيع الأرباح ربع السنوية الربع الثاني لعام 2019</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>9</span></p>
                  </td>
                  <td>
                    <p><span>3/9/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>10</span></p>
                  </td>
                  <td>
                    <p><span>30/9/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>11</span></p>
                  </td>
                  <td>
                    <p><span>29/10/2019م</span></p>
                  </td>
                  <td>
                    <p><span>توزيع الأرباح ربع السنوية الربع الثالث لعام 2019</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>12</span></p>
                  </td>
                  <td>
                    <p><span>28/11/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
                <tr>
                  <td>
                    <p><span>13</span></p>
                  </td>
                  <td>
                    <p><span>31/12/2019م</span></p>
                  </td>
                  <td>
                    <p><span>تحديث سجل المساهمين الشهري</span></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>

      </div>
    <!-- SECTION1 -->
   
    
</div>

   <!--  <div class="bar-wrap">
        <div class="element_bars_hr" style="width: 30%;top: 0;left: 0;z-index: 1;">
          <div class="rightbar bk_purple" style="width: 50%"></div>
          <div class="leftbar bk_pink" style="width: 50%"></div>
        </div>
        <div class="element_bars_hr" style=" width: 15%;top: 0;right: 20%;z-index: 1;">
          <div class="rightbar bk_purple" style="width: 0%"></div>
          <div class="leftbar bk_pink" style="width: 100%"></div>
        </div>
    </div> -->
   
  </div>

  <!-- video section | consolidate_financials -->
    <div class="video_wrapper" style="z-index: 99; width: 100%; height: 100vh; position: fixed; top: 0;">
      <video id="category_video" playsinline="" xmuted style="width: 100%; height: 100vh; object-fit: cover; ">
        <source src="video/company_profile.mp4" type="video/mp4">
      </video>
    </div>
  <!-- video section | consolidate_financials -->

  <?php require_once 'scripts.php'; ?>
  <script type="text/javascript" src="js/inner_page.js"></script>
</body>

</html>